package com.sursan.Springsecuritybasicapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecuritybasicappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecuritybasicappApplication.class, args);
	}

}
