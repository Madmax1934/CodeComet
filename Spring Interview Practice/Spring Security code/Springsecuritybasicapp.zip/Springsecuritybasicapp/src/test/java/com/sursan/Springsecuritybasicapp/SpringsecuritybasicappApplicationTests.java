package com.sursan.Springsecuritybasicapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecuritybasicappApplicationTests {

	@Test
	void contextLoads() {
	}

}
