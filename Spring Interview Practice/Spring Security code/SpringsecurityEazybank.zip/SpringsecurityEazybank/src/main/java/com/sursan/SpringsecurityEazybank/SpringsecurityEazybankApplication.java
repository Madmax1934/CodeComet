package com.sursan.SpringsecurityEazybank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityEazybankApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecurityEazybankApplication.class, args);
	}

}
