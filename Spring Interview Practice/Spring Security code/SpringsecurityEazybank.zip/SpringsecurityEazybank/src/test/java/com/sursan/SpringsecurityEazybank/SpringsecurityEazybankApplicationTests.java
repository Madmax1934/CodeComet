package com.sursan.SpringsecurityEazybank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityEazybankApplicationTests {

	@Test
	void contextLoads() {
	}

}
