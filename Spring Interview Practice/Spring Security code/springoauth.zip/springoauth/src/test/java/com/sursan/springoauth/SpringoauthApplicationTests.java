package com.sursan.springoauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringoauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
