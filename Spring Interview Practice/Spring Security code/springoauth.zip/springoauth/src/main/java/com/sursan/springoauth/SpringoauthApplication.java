package com.sursan.springoauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringoauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringoauthApplication.class, args);
	}

}
